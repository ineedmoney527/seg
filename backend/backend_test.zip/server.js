const express = require("express");

const app = express();

const errorHandler = require("./middleware/errorHandler");
//to access env file
const dotenv = require("dotenv").config();

//stringify reqeust from client to server
app.use(express.json());

app.use("/api/user", require("./route/user"));
app.use(errorHandler);

app.listen(3334, () => {
  console.log(`Server running at `);
});
