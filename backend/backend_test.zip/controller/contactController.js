// When an error is caught, asyncHandler passes it to Express's error handling middleware by calling next(error). This allows Express to handle the error appropriately.
//allows us to catch error and pass to errorHandler.js
//without it , we juz throw error and cant respond properly with {message:, error:....}
const asyncHandler = require("express-async-handler");
const db = require("../config/dbConnection");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");

function validateInput(req, res) {
  const schema = Joi.object({
    username: Joi.string().required(),
    email: Joi.string().email().required(),
    password: Joi.string()
      .min(5)
      .max(30)
      .pattern(new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*])"))
      .required(),
    type: Joi.string().valid("S", "L").required(),
  });

  const { error, value } = schema.validate(req.body);
  if (error) {
    res.status(400).json({ message: error.details[0].message });
    return null;
  }

  return value;
}

function handleQueryError(res, err) {
  switch (err.code) {
    // Check for duplicate entry
    case "ER_DUP_ENTRY":
      let errorMessage = "";
      if (err.sqlMessage.includes("email"))
        errorMessage = "Email already exists";
      else if (err.sqlMessage.includes("password"))
        errorMessage = "Password already exists";
      return res.status(500).json({ message: errorMessage });
    default:
      return res.status(500).json({ err });
  }
}

//@desc Create new contats
//@route POST /api/user
//@access public
const Joi = require("joi");

const createUser = async (req, res) => {
  //field validation
  const validatedData = validateInput(req, res);
  if (!validatedData) {
    // null is returned in passwordHandler
    return;
  }

  //insert query
  const { username, email, password, type } = validatedData;
  const hashedPassword = await bcrypt.hash(password, 10);
  db.query(
    "INSERT INTO user (username, email, password, type_id) VALUES (?, ?, ?, ?)",
    [username, email, hashedPassword, type],
    (err, data) =>
      err ? handleQueryError(res, err) : res.json("User successfully added")
  );
};

//@desc Get all contats
//@route GET /api/user
//@access public
const readUser = (req, res) => {
  const query = "SELECT * FROM user";
  db.query(query, (err, data) => res.json(err ? err : data));
};
//@desc Get contact by id
//@route GET /api/contacts/:id
//@access public
const readContactById = asyncHandler(async (req, res) => {
  const query = "SELECT * FROM user where `id`=" + req.params.id;
  db.query(query, (err, data) =>
    res.json(err ? { message: "User not found" } : data)
  );
});

//@desc Update contact by id
//@route PUT /api/contacts/:id
//@access public
const updateContact = async (req, res) => {
  const userId = req.params.id;
  console.log(userId);
  const validatedData = validateInput(req, res);
  if (!validatedData) {
    // null is returned in validateInput
    return;
  }
  const { username, email, password, type } = validatedData;
  const hashedPassword = await bcrypt.hash(password, 10);
  const queryString =
    "UPDATE user SET `username` = ?, `email`=?, `password`=?, `type_id`=? WHERE `id`=?";
  db.query(
    queryString,
    [username, email, hashedPassword, type, userId],
    (err, data) =>
      err ? handleQueryError(res, err) : res.json("User successfully updated")
  );
};

//@desc Delete contact by id
//@route  DELETE /api/contacts/:id
//@access public
const deleteContact = (req, res) => {
  const queryString = "DELETE FROM user WHERE `id` =" + req.params.id;
  db.query(queryString, (err, data) =>
    res.json(err ? { message: err.message } : "User deleted successfully")
  );
};

const login = (req, res) => {
  const { username, password } = req.body;

  // Check if username exists in the database
  db.query(
    "SELECT * FROM user WHERE username = ?",
    [username],
    async (err, results) => {
      if (err) {
        throw err;
      }
      if (results.length === 0) {
        return res
          .status(401)
          .json({ message: "Invalid username or password" });
      }

      // Compare hashed password with provided password
      const user = results[0];

      try {
        if (await bcrypt.compare(password, user.password)) {
          // Passwords match, generate JWT token
          const token = jwt.sign(
            { username: user.username },
            "your_secret_key",
            { expiresIn: "1h" }
          );

          // Store token in cookies
          res.cookie("token", token, { httpOnly: true, maxAge: 3600000 }); // 1 hour expiration

          return res.status(200).json({ message: "Login successful", token });
        } else {
          // Passwords don't match
          return res
            .status(401)
            .json({ message: "Invalid username or password" });
        }
      } catch (error) {
        return res
          .status(500)
          .json({ message: "Internal Server Error" + error.message });
      }
    }
  );
};

module.exports = {
  createUser,
  readUser,
  readContactById,
  deleteContact,
  updateContact,
  login,
};
