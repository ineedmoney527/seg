const express = require("express");
const router = express.Router();

const {
  createUser,
  readUser,
  readContactById,
  deleteContact,
  updateContact,
  login,
} = require("../controller/contactController");
//create
router.post("/", createUser);
//read
router.get("/", readUser);

//readbyId
router.get("/:id", readContactById);

//update
router.put("/:id", updateContact);

//delete
router.delete("/:id", deleteContact);

//login
router.post("/login", login);

module.exports = router;
